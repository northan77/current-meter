from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from smbus2 import SMBus


@dataclass(frozen=True)
class INA228Registers:
    CONFIG: int = 0x00
    ADC_CONFIG: int = 0x01
    SHUNT_CAL: int = 0x02
    SHUNT_TEMPCO: int = 0x03
    VSHUNT: int = 0x04
    VBUS: int = 0x05
    DIETEMP: int = 0x06
    CURRENT: int = 0x07
    POWER: int = 0x08
    ENERGY: int = 0x09
    CHARGE: int = 0x0A
    DIAG_ALRT: int = 0x0B
    MANUFACTURER_ID: int = 0x3E
    DEVICE_ID: int = 0x3F


REG = INA228Registers()


def _twos_complement(value: int, bits: int) -> int:
    sign_bit = 1 << (bits - 1)
    return value - (1 << bits) if value & sign_bit else value


class INA228:
    """Small INA228 Phase 0 probe driver.

    This is deliberately conservative. It reads raw registers and derives
    simple values from shunt voltage divided by the configured shunt value.
    Full CURRENT/POWER register calibration belongs in Phase 2.
    """

    def __init__(self, bus: int = 1, address: int = 0x40) -> None:
        self.bus_no = bus
        self.address = address
        self.bus = SMBus(bus)

    def close(self) -> None:
        self.bus.close()

    def __enter__(self) -> "INA228":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def read_u16(self, register: int) -> int:
        data = self.bus.read_i2c_block_data(self.address, register, 2)
        return (data[0] << 8) | data[1]

    def read_s16(self, register: int) -> int:
        return _twos_complement(self.read_u16(register), 16)

    def read_u24(self, register: int) -> int:
        data = self.bus.read_i2c_block_data(self.address, register, 3)
        return (data[0] << 16) | (data[1] << 8) | data[2]

    def read_s24(self, register: int) -> int:
        return _twos_complement(self.read_u24(register), 24)

    def read_u40(self, register: int) -> int:
        data = self.bus.read_i2c_block_data(self.address, register, 5)
        value = 0
        for b in data:
            value = (value << 8) | b
        return value

    def read_s40(self, register: int) -> int:
        return _twos_complement(self.read_u40(register), 40)

    def ping(self) -> bool:
        try:
            self.read_u16(REG.DEVICE_ID)
            return True
        except OSError:
            return False

    def read_identity(self) -> dict[str, int]:
        return {
            "manufacturer_id": self.read_u16(REG.MANUFACTURER_ID),
            "device_id": self.read_u16(REG.DEVICE_ID),
        }

    def read_key_registers(self) -> dict[str, int]:
        return {
            "config": self.read_u16(REG.CONFIG),
            "adc_config": self.read_u16(REG.ADC_CONFIG),
            "shunt_cal": self.read_u16(REG.SHUNT_CAL),
            "shunt_tempco": self.read_u16(REG.SHUNT_TEMPCO),
            "vshunt_raw": self.read_s24(REG.VSHUNT),
            "vbus_raw": self.read_u24(REG.VBUS),
            "dietemp_raw": self.read_s16(REG.DIETEMP),
            "current_raw": self.read_s24(REG.CURRENT),
            "power_raw": self.read_u24(REG.POWER),
            "diag_alrt": self.read_u16(REG.DIAG_ALRT),
        }

    def adcrange_low_range_enabled(self) -> bool:
        # CONFIG bit 4 ADCRANGE: 0 = ±163.84 mV, 1 = ±40.96 mV.
        return bool(self.read_u16(REG.CONFIG) & (1 << 4))

    def read_vshunt_v(self) -> float:
        lsb = 78.125e-9 if self.adcrange_low_range_enabled() else 312.5e-9
        return self.read_s24(REG.VSHUNT) * lsb

    def read_vbus_v(self) -> float:
        return self.read_u24(REG.VBUS) * 195.3125e-6

    def read_die_temp_c(self) -> float:
        return self.read_s16(REG.DIETEMP) * 0.0078125

    def read_simple_measurement(self, shunt_ohms: float, current_multiplier: float = 1.0, voltage_multiplier: float = 1.0, current_zero_offset_a: float = 0.0) -> dict[str, float]:
        bus_v = self.read_vbus_v() * voltage_multiplier
        shunt_v = self.read_vshunt_v()
        current_a = ((shunt_v / shunt_ohms) * current_multiplier) - current_zero_offset_a
        power_w = bus_v * current_a
        return {
            "bus_v": bus_v,
            "shunt_v": shunt_v,
            "current_a_simple": current_a,
            "power_w_simple": power_w,
            "die_temp_c": self.read_die_temp_c(),
        }


def scan_i2c_bus(bus_no: int = 1, start: int = 0x03, end: int = 0x77) -> list[int]:
    found: list[int] = []
    with SMBus(bus_no) as bus:
        for addr in range(start, end + 1):
            try:
                bus.write_quick(addr)
                found.append(addr)
            except OSError:
                pass
    return found


def format_hex_addresses(addresses: Iterable[int]) -> list[str]:
    return [f"0x{addr:02X}" for addr in addresses]
